using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace Stickman;

internal static class Program
{
    [STAThread] static void Main()
    {
        using var mutex=new Mutex(true,"WhiteStickman_v4_SingleInstance",out bool fresh);
        if(!fresh) return;
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new PetForm());
    }
}
internal sealed partial class PetForm : Form
{
    readonly Body body;
    readonly System.Windows.Forms.Timer timer=new(){Interval=8};
    readonly Stopwatch clock=Stopwatch.StartNew();
    readonly Queue<(double T,Vector2 P)> samples=new();
    readonly NotifyIcon tray;
    readonly ContextMenuStrip menu=new();
    double last, accumulator, lastTop, lastWindows;
    Vector2 grabOffset;
    bool closing;
    const int ExitHotkey=902;
    protected override bool ShowWithoutActivation=>true;
    protected override CreateParams CreateParams
    {
        get { var p=base.CreateParams; p.ExStyle|=0x80000|0x80|0x08000000; return p; }
    }
    public PetForm()
    {
        Text="White Stickman v4"; FormBorderStyle=FormBorderStyle.None;
        ShowInTaskbar=false; TopMost=true; StartPosition=FormStartPosition.Manual;
        AutoScaleMode=AutoScaleMode.None; ClientSize=new Size(240,240);
        body=new Body(Screen.PrimaryScreen!.WorkingArea);
        Location=new Point((int)body.Center.X-120,(int)body.Center.Y-120);
        SetupOptions();
        tray=new NotifyIcon { Icon=SystemIcons.Application,Text="White Stickman v4 — ПКМ: выход",Visible=true,ContextMenuStrip=menu };
        MouseDown+=Down; MouseUp+=Up;
        MouseMove+=(_,_)=>{if(body.Held>=0 && !body.Attached) Sample();};
        MouseCaptureChanged+=(_,_)=>{if(!Capture && body.Held>=0 && !body.Attached) body.Release(Vector2.Zero);};
        Shown+=(_,_)=>{Native.RegisterHotKey(Handle,ExitHotkey,0x4000|0x2|0x4,0x51);last=clock.Elapsed.TotalSeconds;Render();timer.Start();};
        timer.Tick+=(_,_)=>TickFrame();
    }
    static Vector2 MousePositionVector(){var p=Cursor.Position;return new Vector2(p.X,p.Y);}
    void Sample()
    {
        var m=MousePositionVector(); double now=clock.Elapsed.TotalSeconds;
        samples.Enqueue((now,m)); while(samples.Count>1 && now-samples.Peek().T>.085) samples.Dequeue();
        body.Target=m+grabOffset;
    }
    void Down(object? sender,MouseEventArgs e)
    {
        if(e.Button==MouseButtons.Right) {menu.Show(Cursor.Position);return;}
        if(e.Button!=MouseButtons.Left) return;
        body.Detach(Vector2.Zero);
        var m=MousePositionVector();
        int a=0,b=0;float t=0,best=MathF.Max(0,Vector2.Distance(body.P[0],m)-16);
        Vector2 grab=body.P[0];
        foreach(var line in body.Lines)
        {
            var d=body.P[line.B]-body.P[line.A];
            float u=Math.Clamp(Vector2.Dot(m-body.P[line.A],d)/MathF.Max(d.LengthSquared(),.01f),0,1);
            var point=Vector2.Lerp(body.P[line.A],body.P[line.B],u);
            float distance=MathF.Max(0,Vector2.Distance(point,m)-6.5f);
            if(distance<best){best=distance;a=line.A;b=line.B;t=u;grab=point;}
        }
        if(best>10)return;
        grabOffset=grab-m;samples.Clear();body.GrabSegment(a,b,t,grab);Sample();Capture=true;
    }
    void Up(object? sender,MouseEventArgs e)
    {
        if(e.Button!=MouseButtons.Left || body.Held<0 || body.Attached) return;
        Sample(); var first=samples.Peek(); double dt=clock.Elapsed.TotalSeconds-first.T;
        var v=dt>.012?(MousePositionVector()-first.P)/(float)dt:Vector2.Zero;
        body.Release(v);Capture=false;samples.Clear();
    }
    void TickFrame()
    {
        if(closing) return;
        if(menu.Visible || editing){last=clock.Elapsed.TotalSeconds;accumulator=0;return;}
        double now=clock.Elapsed.TotalSeconds;
        accumulator+=Math.Min(now-last,.08);last=now;
        var mouse=MousePositionVector();
        if(body.Held>=0 && !body.Attached) Sample();
        UpdateScreens();
        if(now-lastWindows>.08){body.SetObstacles(ExplorerWindows.Read(body.Area));lastWindows=now;}
        while(accumulator>=Body.Dt) {body.Control(mouse);body.Step(mouse);body.AfterStep();accumulator-=Body.Dt;}
        Render();
        if(now-lastTop>1) {Native.SetWindowPos(Handle,new IntPtr(-1),0,0,0,0,0x1|0x2|0x10);lastTop=now;}
    }
    void Render()
    {
        // Bounds follow every joint and head radius, not the original upright rectangle.
        float left=float.MaxValue,top=float.MaxValue,right=float.MinValue,bottom=float.MinValue;
        for(int i=0;i<14;i++)
        {
            float r=body.Radius(i)+12;var p=body.P[i];
            left=MathF.Min(left,p.X-r);right=MathF.Max(right,p.X+r);
            top=MathF.Min(top,p.Y-r);bottom=MathF.Max(bottom,p.Y+r);
        }
        int x=(int)MathF.Floor(left)-2,y=(int)MathF.Floor(top)-2;
        int w=Math.Max(1,(int)MathF.Ceiling(right)-x+3),h=Math.Max(1,(int)MathF.Ceiling(bottom)-y+3);
        using var bitmap=new Bitmap(w,h,PixelFormat.Format32bppArgb);
        using(var g=Graphics.FromImage(bitmap))
        {
            g.Clear(Color.Transparent);g.SmoothingMode=SmoothingMode.AntiAlias;
            g.TranslateTransform(-x,-y);
            // A nearly transparent 24px hit halo makes thin joints easy to grab,
            // while the rest of the desktop remains click-through.
            using var hit=new Pen(Color.FromArgb(1,255,255,255),24){StartCap=LineCap.Round,EndCap=LineCap.Round};
            foreach(var link in body.Lines)Line(g,hit,link.A,link.B);
            using var outline=new Pen(Color.FromArgb(230,35,39,46),13){StartCap=LineCap.Round,EndCap=LineCap.Round,LineJoin=LineJoin.Round};
            using var paint=CharacterBrush(new RectangleF(left,top,right-left,bottom-top));
            using var white=new Pen(paint,9){StartCap=LineCap.Round,EndCap=LineCap.Round,LineJoin=LineJoin.Round};
            foreach(var link in body.Lines) Line(g,outline,link.A,link.B);
            foreach(var link in body.Lines) Line(g,white,link.A,link.B);
            foreach(int joint in new[]{6,7,10,11})
                g.FillEllipse(paint,body.P[joint].X-4.5f,body.P[joint].Y-4.5f,9,9);
            DrawSkirt(g,paint);
            var head=body.P[0]; var d=head-body.P[1];
            float rotation=MathF.Atan2(d.Y,d.X)*180/MathF.PI+90;
            g.TranslateTransform(head.X,head.Y);g.RotateTransform(rotation);
            using var dark=new SolidBrush((options.Color==1?Color.White:Color.FromArgb(255,35,39,46)));
            g.FillEllipse(dark,-16,-16,32,32);g.FillEllipse(paint,-14.5f,-14.5f,29,29);
            if(face!=null){using var circle=new GraphicsPath();circle.AddEllipse(-14.5f,-14.5f,29,29);g.SetClip(circle);g.DrawImage(face,-14.5f,-14.5f,29,29);g.ResetClip();}
            if(face==null){
            bool panic=!body.Standing;
            float eyeH=panic?6:4;
            g.FillEllipse(dark,-7,-5,3.5f,eyeH);g.FillEllipse(dark,3.5f,-5,3.5f,eyeH);
            if(panic) g.FillEllipse(dark,-3,4,6,8);
            else {using var mouth=new Pen((options.Color==1?Color.White:Color.FromArgb(255,35,39,46)),1.6f);g.DrawArc(mouth,-4,3,8,5,0,180);}
        }
        }
        Native.Push(Handle,bitmap,x,y);
    }
    void Line(Graphics g,Pen pen,int a,int b)=>g.DrawLine(pen,body.P[a].X,body.P[a].Y,body.P[b].X,body.P[b].Y);
    protected override void WndProc(ref Message m)
    {
        if(m.Msg==0x312 && m.WParam.ToInt32()==ExitHotkey) {Close();return;}
        if(m.Msg==0x21) {m.Result=new IntPtr(3);return;} // MA_NOACTIVATE
        base.WndProc(ref m);
    }
    protected override void Dispose(bool disposing)
    {
        if(disposing && !closing)
        {closing=true;timer.Stop();timer.Dispose();Native.UnregisterHotKey(Handle,ExitHotkey);tray.Visible=false;tray.Dispose();menu.Dispose();}
        base.Dispose(disposing);
    }
}
internal static class Native
{
    [StructLayout(LayoutKind.Sequential)] struct Pt {public int X,Y;public Pt(int x,int y){X=x;Y=y;}}
    [StructLayout(LayoutKind.Sequential)] struct Sz {public int W,H;public Sz(int w,int h){W=w;H=h;}}
    [StructLayout(LayoutKind.Sequential,Pack=1)] struct Blend {public byte Op,Flags,Alpha,Format;}
    [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr h);
    [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr h,IntPtr dc);
    [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr dc);
    [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr dc);
    [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr dc,IntPtr obj);
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
    [DllImport("user32.dll",SetLastError=true)] static extern bool UpdateLayeredWindow(IntPtr h,IntPtr dc,ref Pt dst,ref Sz size,IntPtr src,ref Pt origin,uint key,ref Blend blend,uint flags);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int height,uint flags);
    [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr h,int id,uint modifiers,uint key);
    [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr h,int id);
    public static void Push(IntPtr window,Bitmap image,int x,int y)
    {
        IntPtr screen=GetDC(IntPtr.Zero),dc=CreateCompatibleDC(screen),hb=IntPtr.Zero,old=IntPtr.Zero;
        try
        {
            hb=image.GetHbitmap(Color.FromArgb(0));old=SelectObject(dc,hb);
            var dest=new Pt(x,y);var origin=new Pt(0,0);var size=new Sz(image.Width,image.Height);
            var blend=new Blend{Op=0,Flags=0,Alpha=255,Format=1};
            if(!UpdateLayeredWindow(window,screen,ref dest,ref size,dc,ref origin,0,ref blend,2))
                throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        }
        finally
        {
            if(old!=IntPtr.Zero)SelectObject(dc,old);
            if(hb!=IntPtr.Zero)DeleteObject(hb);
            DeleteDC(dc);ReleaseDC(IntPtr.Zero,screen);
        }
    }
}
