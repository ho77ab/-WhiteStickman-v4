using System.Numerics;
namespace Stickman;

// Verlet integration, weighted distance constraints and active joint motors.
internal sealed partial class Body
{
    public const float Dt = 1f / 120;
    public readonly Vector2[] P = new Vector2[14], Old = new Vector2[14];
    readonly Vector2[] force = new Vector2[14];
    readonly float[] mass = { 2.2f, 1.5f, 2, 2.5f, .7f, .7f, .6f, .6f, .4f, .4f, 1, 1, .7f, .7f };
    public readonly (int A, int B)[] Lines = { (1,2),(2,3),(4,5),(4,6),(6,8),(5,7),(7,9),(3,10),(10,12),(3,11),(11,13),(0,1) };
    readonly List<(int A, int B, float Min, float Max)> links = new();
    public Rectangle Area;
    public int Held = -1;
    public Vector2 Target;
    public bool Standing = true, Running;
    public float Time, Phase, Facing = 1;
    float anchor, runSpeed, recovery = 1, floorTime, releaseAge, scared;
    public float Radius(int i) => i == 0 ? 16 : 6.5f;
    public Vector2 Center => (P[0] + P[2] + P[3]) / 3;

    public Body(Rectangle area)
    {
        Area = area; anchor = area.Left + area.Width * .55f;
        Link(0,1,23); Link(1,2,16); Link(2,3,26); Link(1,3,42);
        Link(1,4,8.94f); Link(1,5,8.94f); Link(2,4,14.42f); Link(2,5,14.42f); Link(4,5,16);
        Link(4,6,26); Link(6,8,25); Link(5,7,26); Link(7,9,25);
        Link(3,10,32); Link(10,12,32); Link(3,11,32); Link(11,13,32);
        links.Add((0,2,29,39)); // flexible neck, but no backward folding into chest
        links.Add((4,8,13,50.5f)); links.Add((5,9,13,50.5f));
        links.Add((3,12,18,63.8f)); links.Add((3,13,18,63.8f));
        var pose = Pose(); Array.Copy(pose,P,14); Array.Copy(P,Old,14);
    }
    void Link(int a,int b,float length) => links.Add((a,b,length,length));
    public static Vector2 Limit(Vector2 v,float max) => v.LengthSquared() > max*max ? Vector2.Normalize(v)*max : v;
    static float Wrap(float a) => MathF.Atan2(MathF.Sin(a),MathF.Cos(a));
    public void Grab(int index,Vector2 target)
    {
        Held=index; heldB=index; heldT=0; Target=target; Standing=false; Running=false; floorTime=0; recovery=0; supportId=IntPtr.Zero;
    }
    public void Release(Vector2 velocity)
    {
        if(Held<0) return;
        velocity=Limit(velocity,1800);
        var lever=Vector2.Lerp(P[Held],P[heldB],heldT)-Center;
        float spin=Math.Clamp((lever.X*velocity.Y-lever.Y*velocity.X)/6500,-13,13);
        for(int i=0;i<14;i++)
        {
            var r=P[i]-Center;
            var v=Limit((P[i]-Old[i])/Dt,1800)*.25f + velocity*.75f;
            v+=new Vector2(-r.Y,r.X)*spin*.55f;
            Old[i]=P[i]-Limit(v,2200)*Dt;
        }
        Held=-1; releaseAge=0; floorTime=0;
    }
    Vector2[] Pose()
    {
        float floor=SupportTop-8.5f;
        float stride=Math.Clamp(MathF.Abs(runSpeed)/170,0,1);
        float bob=landingCrouch*12+MathF.Abs(MathF.Sin(Phase))*3*stride;
        float lean=runSpeed*.035f;
        var hip=new Vector2(anchor,floor-59+bob);
        var neck=hip+new Vector2(lean,-42);
        var q=new Vector2[14]; q[3]=hip; q[1]=neck; q[2]=Vector2.Lerp(neck,hip,16f/42);
        q[0]=neck+new Vector2(MathF.Sin(Time*1.7f)*2+Facing*stride*3,-23);
        q[4]=neck+new Vector2(-8,4); q[5]=neck+new Vector2(8,4);
        for(int side=0;side<2;side++)
        {
            float sign=side==0?-1:1;
            float cycle=Phase+side*MathF.PI;
            var foot=new Vector2(anchor+sign*13+MathF.Sin(cycle)*24*stride,
                floor-MathF.Max(0,MathF.Cos(cycle))*20*stride);
            q[12+side]=foot;
            q[10+side]=Knee(hip,foot,32,32,Facing);
            int shoulder=4+side;
            float swing=MathF.Sin(cycle)*.32f*stride;
            // Screen-left shoulder extends left (cos must be negative).
            float upper=MathF.PI/2-sign*(.48f+swing);
            float lower=upper-sign*(.16f+.50f*stride);
            q[6+side]=q[shoulder]+new Vector2(MathF.Cos(upper),MathF.Sin(upper))*26;
            q[8+side]=q[6+side]+new Vector2(MathF.Cos(lower),MathF.Sin(lower))*25;
        }
        return q;
    }
    static Vector2 Knee(Vector2 a,Vector2 b,float l1,float l2,float side)
    {
        var d=b-a; float n=Math.Clamp(d.Length(),.01f,l1+l2-.1f); var u=Vector2.Normalize(d);
        float along=(l1*l1-l2*l2+n*n)/(2*n);
        float h=MathF.Sqrt(MathF.Max(0,l1*l1-along*along));
        return a+u*along+new Vector2(u.Y,-u.X)*h*side;
    }
    void Motor(int a,int b,float target,float strength)
    {
        var d=P[b]-P[a]; float n=MathF.Max(d.Length(),1); var u=d/n;
        float error=Wrap(target-MathF.Atan2(d.Y,d.X));
        var tangent=new Vector2(-u.Y,u.X);
        float speed=Vector2.Dot(((P[b]-Old[b])-(P[a]-Old[a]))/Dt,tangent);
        var f=tangent*Math.Clamp(error*strength-speed*2,-5500,5500);
        force[b]+=f; force[a]-=f*mass[b]/mass[a];
    }
    public void Step(Vector2 mouse)
    {
        Time+=Dt; releaseAge+=Dt; Array.Clear(force);
        CheckSupport();
        Array.Copy(P,stepStart,14);
        if(Standing && Held<0)
        {
            float distance=Vector2.Distance(mouse,Center);
            if(calm<=0 && recovery>.95f && (Hunter || distance<190)) { scared=.65f; Facing=mouse.X<P[3].X?1:-1; if(Hunter)Facing=-Facing; }
            scared=MathF.Max(0,scared-Dt); Running=scared>0 && calm<=0 && (!Hunter || MathF.Abs(mouse.X-P[3].X)>18);
            float desired=Running?Facing*185:0;
            if((anchor<Area.Left+57 && desired<0)||(anchor>Area.Right-57 && desired>0)) desired=0;
            runSpeed+=(desired-runSpeed)*MathF.Min(1,Dt*7);
            anchor=Math.Clamp(anchor+runSpeed*Dt,Area.Left+52,Area.Right-52);
            Phase+=Dt*(3+MathF.Abs(runSpeed)*.062f);
            recovery=MathF.Min(1,recovery+Dt*1.8f);
            var pose=Pose();
            for(int i=0;i<14;i++)
            {
                var v=(P[i]-Old[i])/Dt;
                force[i]+=Limit((pose[i]-P[i])*(170*recovery)-v*(20*recovery),16000);
                force[i].Y-=1200*recovery;
            }
        }
        else
        {
            float up=MathF.Atan2(P[1].Y-P[3].Y,P[1].X-P[3].X);
            float frantic=Held>=0?12:14;
            for(int side=0;side<2;side++)
            {
                float s=side==0?-1:1, t=Time*frantic+side*MathF.PI;
                Motor(4+side,6+side,up+s*(1.1f+MathF.Sin(t)*1.0f),2300);
                Motor(6+side,8+side,up+s*(.2f+MathF.Sin(t+1)*1.4f),1900);
                Motor(3,10+side,up+MathF.PI+s*.25f+MathF.Sin(t*.75f)*.75f,1700);
                Motor(10+side,12+side,up+MathF.PI+MathF.Sin(t*.75f+1)*1.1f,1400);
            }
            Motor(1,0,up+MathF.Sin(Time*8)*.35f,700);
        }
        for(int i=0;i<14;i++)
        {
            if(i==Held && heldB==Held) continue;
            var p=P[i]; var v=Limit(P[i]-Old[i],2200*Dt)*.997f;
            P[i]+=v+(force[i]+new Vector2(0,1200))*Dt*Dt; Old[i]=p;
        }
        var target=Target;
        if(Held>=0)
        {
            float r=Radius(Held);
            target=Vector2.Clamp(target,new Vector2(Area.Left+r+2,Area.Top+r+2),new Vector2(Area.Right-r-2,Area.Bottom-r-2));
            var current=Vector2.Lerp(stepStart[Held],stepStart[heldB],heldT);
            target=current+Limit(target-current,24);
        }
        for(int iteration=0;iteration<16;iteration++)
        {
            if(Held>=0) Pin(target);
            foreach(var l in links)
            {
                var d=P[l.B]-P[l.A]; float length=d.Length(); if(length<.001f) continue;
                float desired=Math.Clamp(length,l.Min,l.Max);
                float wa=InvMass(l.A), wb=InvMass(l.B);
                var correction=d*((length-desired)/(length*(wa+wb)));
                P[l.A]+=correction*wa; P[l.B]-=correction*wb;
            }
            // Prevent the head passing through the torso or hands.
            for(int i=2;i<14;i++)
            {
                var d=P[i]-P[0]; float len=d.Length(), min=Radius(i)+16;
                if(len>.001f && len<min)
                {
                    float wa=InvMass(0), wb=InvMass(i);
                    var c=d*((min-len)/(len*(wa+wb))); P[i]+=c*wb; P[0]-=c*wa;
                }
            }
            var before=(Vector2[])P.Clone();
            OrientShoulders();
            for(int j=0;j<14;j++)Old[j]+=P[j]-before[j];
            for(int i=0;i<14;i++) { CollideWindows(i); Collide(i,iteration==15); }
            if(iteration%4==3) CollideBones();
        }
        if(Held>=0)
        {
            // Obstacles win over the mouse constraint: dragging cannot pull a limb through a window.
            if(heldB==Held) Old[Held]=P[Held];
        }
        if(!Standing && Held<0)
        {
            bool onFloor=FindLanding(out var landing); float speed=0;
            for(int i=0;i<14;i++) speed+=(P[i]-Old[i]).Length()/Dt;
            floorTime=onFloor?floorTime+Dt:MathF.Max(0,floorTime-Dt*.4f);
            if(floorTime>.20f && releaseAge>.25f && speed/14<420)
            {
                supportId=landing.Id; supportRect=landing.Rect;
                calm=.85f;scared=0;landingCrouch=1;jumping=false;Array.Copy(P,Old,14);
                Standing=true; recovery=0; anchor=Math.Clamp(P[3].X,Area.Left+52,Area.Right-52); runSpeed=0;
            }
        }
    }
    void Collide(int i,bool final)
    {
        float r=Radius(i)+2;
        var p=P[i]; var v=P[i]-Old[i]; bool x=false,y=false;
        if(p.X<Area.Left+r) { p.X=Area.Left+r; x=v.X<0; }
        if(p.X>Area.Right-r) { p.X=Area.Right-r; x=v.X>0; }
        if(p.Y<Area.Top+r) { p.Y=Area.Top+r; y=v.Y<0; }
        float localFloor=FloorAt(p.X);
        if(p.Y>localFloor-r) { p.Y=localFloor-r; y=v.Y>0; }
        if(x) { v.X*=-.3f; v.Y*=.9f; }
        if(y) { v.Y=MathF.Abs(v.Y)>1.2f?v.Y*-.24f:0; v.X*=Standing?.85f:.76f; }
        P[i]=p;
        if(x||y) Old[i]=p-v;
    }
}
