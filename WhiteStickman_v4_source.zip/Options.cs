using System.Drawing.Drawing2D;
using System.Numerics;
using System.Text.Json;
namespace Stickman;
internal sealed class Options
{
    public bool Hunter {get;set;}
    public bool Girl {get;set;}
    public int Color {get;set;}
    public bool AllScreens {get;set;}
    public static string Folder=>Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),"WhiteStickman");
    public static Options Load(){try{return JsonSerializer.Deserialize<Options>(File.ReadAllText(Path.Combine(Folder,"options.json")))??new();}catch{return new();}}
    public void Save(){try{Directory.CreateDirectory(Folder);File.WriteAllText(Path.Combine(Folder,"options.json"),JsonSerializer.Serialize(this));}catch{}}
}
internal sealed partial class PetForm
{
    Options options=Options.Load();
    Bitmap? face;
    bool editing;
    void SetupOptions()
    {
        body.Hunter=options.Hunter;
        try{using var im=Image.FromFile(Path.Combine(Options.Folder,"face.png"));face=new Bitmap(im);}catch{}
        AddChoices("Поведение",new[]{"Жертва","Охотник"},()=>options.Hunter?1:0,i=>{options.Hunter=i==1;body.Hunter=options.Hunter;if(!body.Hunter)body.Detach(Vector2.Zero);});
        AddChoices("Персонаж",new[]{"Мужчина","Девушка"},()=>options.Girl?1:0,i=>options.Girl=i==1);
        AddChoices("Цвет",new[]{"Белый","Чёрный","Оранжевый","Салатовый","Голубой","Радужный"},()=>options.Color,i=>options.Color=i);
        var faces=new ToolStripMenuItem("Лицо");
        faces.DropDownItems.Add("Загрузить и настроить фото…",null,(_,_)=>EditFace());
        faces.DropDownItems.Add("Вернуть нарисованное лицо",null,(_,_)=>{face?.Dispose();face=null;try{File.Delete(Path.Combine(Options.Folder,"face.png"));}catch{};});
        menu.Items.Add(faces);
        AddChoices("Мониторы",new[]{"Только основной","Все подключённые"},()=>options.AllScreens?1:0,i=>{options.AllScreens=i==1;UpdateScreens();});
        menu.Items.Add(new ToolStripSeparator());menu.Items.Add("Выход",null,(_,_)=>Close());
    }
    void AddChoices(string title,string[] choices,Func<int> selected,Action<int> apply)
    {
        var group=new ToolStripMenuItem(title);menu.Items.Add(group);
        for(int n=0;n<choices.Length;n++)
        {
            int index=n;var item=new ToolStripMenuItem(choices[n]);group.DropDownItems.Add(item);
            item.Click+=(_,_)=>{apply(index);options.Save();foreach(ToolStripMenuItem x in group.DropDownItems)x.Checked=group.DropDownItems.IndexOf(x)==selected();};
            item.Checked=n==selected();
        }
    }
    void EditFace()
    {
        editing=true;body.Detach(Vector2.Zero);
        try
        {
            using var dialog=new FaceEditor();
            if(dialog.ShowDialog()==DialogResult.OK && dialog.Result!=null)
            {
                face?.Dispose();face=new Bitmap(dialog.Result);
                try{Directory.CreateDirectory(Options.Folder);face.Save(Path.Combine(Options.Folder,"face.png"),System.Drawing.Imaging.ImageFormat.Png);}catch(Exception ex){MessageBox.Show("Не удалось сохранить лицо: "+ex.Message);}
            }
        }
        finally{editing=false;last=clock.Elapsed.TotalSeconds;accumulator=0;}
    }
    void UpdateScreens()
    {
        var screens=options.AllScreens?Screen.AllScreens.Select(s=>s.WorkingArea).ToArray():new[]{Screen.PrimaryScreen!.WorkingArea};
        body.Screens=screens;
        body.Area=screens.Aggregate(Rectangle.Union);
        if(!screens.Any(r=>r.Contains((int)body.Center.X,(int)body.Center.Y)))
        {
            var r=screens.OrderBy(r=>Vector2.DistanceSquared(body.Center,new Vector2(r.Left+r.Width/2,r.Top+r.Height/2))).First();
            var delta=new Vector2(r.Left+r.Width/2,r.Bottom-85)-body.Center;
            for(int i=0;i<14;i++){body.P[i]+=delta;body.Old[i]=body.P[i];}
            body.Grab(0,body.P[0]);body.Release(Vector2.Zero);
        }
    }
    Brush CharacterBrush(RectangleF bounds)
    {
        Color[] palette={Color.White,Color.FromArgb(20,20,24),Color.DarkOrange,Color.Chartreuse,Color.DeepSkyBlue};
        if(options.Color!=5)return new SolidBrush(palette[Math.Clamp(options.Color,0,4)]);
        var gradient=new LinearGradientBrush(bounds,Color.Red,Color.Blue,45);
        var blend=new ColorBlend(13);
        blend.Positions=Enumerable.Range(0,13).Select(i=>i/12f).ToArray();
        blend.Colors=Enumerable.Range(0,13).Select(i=>Hue(i/12f+body.Time*.18f)).ToArray();gradient.InterpolationColors=blend;
        return gradient;
    }
    static Color Hue(float hue)
    {
        float h=(hue%1)*6;int k=(int)h;int v=(int)(255*(h-k));
        return k switch{0=>Color.FromArgb(255,v,0),1=>Color.FromArgb(255-v,255,0),2=>Color.FromArgb(0,255,v),3=>Color.FromArgb(0,255-v,255),4=>Color.FromArgb(v,0,255),_=>Color.FromArgb(255,0,255-v)};
    }
    void DrawSkirt(Graphics g,Brush brush)
    {
        if(!options.Girl)return;
        var hip=body.P[3];var down=hip-body.P[1];down=Vector2.Normalize(down);var right=new Vector2(down.Y,-down.X);
        Vector2[] pts={hip-right*10-down*4,hip+right*10-down*4,hip+right*23+down*22,hip-right*23+down*22};
        var points=pts.Select(p=>new PointF(p.X,p.Y)).ToArray();
        using var edge=new Pen(options.Color==1?Color.Gray:Color.FromArgb(35,39,46),2);
        g.FillPolygon(brush,points);g.DrawPolygon(edge,points);
    }
}
