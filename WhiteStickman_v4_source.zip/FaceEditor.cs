using System.Drawing.Drawing2D;
namespace Stickman;
internal sealed class FaceEditor:Form
{
    Bitmap? photo;
    public Bitmap? Result;
    readonly Preview canvas=new();
    readonly TrackBar zoom=new(){Minimum=100,Maximum=500,Value=100,TickFrequency=50,Dock=DockStyle.Bottom,Height=48};
    Point last;PointF offset;bool drag;
    float Scale=>photo==null?1:300f/Math.Min(photo.Width,photo.Height)*zoom.Value/100f;
    public FaceEditor()
    {
        Text="Лицо персонажа — круглая обрезка";ClientSize=new Size(530,500);StartPosition=FormStartPosition.CenterScreen;TopMost=true;
        FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;
        var actions=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=48};
        var open=new Button{Text="Загрузить фото…",Width=150};var ok=new Button{Text="Применить",Width=120};var cancel=new Button{Text="Отмена",Width=100};
        actions.Controls.AddRange(new Control[]{open,ok,cancel});Controls.Add(canvas);Controls.Add(zoom);Controls.Add(actions);
        Controls.Add(new Label{Text="Перетащите фото внутри круга. Масштаб — ползунок или колесо мыши.",Dock=DockStyle.Top,Height=36,TextAlign=ContentAlignment.MiddleCenter});
        canvas.Dock=DockStyle.Fill;canvas.Paint+=Draw;
        canvas.MouseDown+=(_,e)=>{if(e.Button==MouseButtons.Left){drag=true;last=e.Location;canvas.Capture=true;}};
        canvas.MouseMove+=(_,e)=>{if(drag){offset.X+=e.X-last.X;offset.Y+=e.Y-last.Y;last=e.Location;Clamp();canvas.Invalidate();}};
        canvas.MouseUp+=(_,_)=>{drag=false;canvas.Capture=false;};
        canvas.MouseWheel+=(_,e)=>zoom.Value=Math.Clamp(zoom.Value+(e.Delta>0?10:-10),100,500);
        zoom.ValueChanged+=(_,_)=>{Clamp();canvas.Invalidate();};
        open.Click+=(_,_)=>LoadPhoto();cancel.Click+=(_,_)=>{DialogResult=DialogResult.Cancel;Close();};
        ok.Click+=(_,_)=>
        {
            if(photo==null){LoadPhoto();return;}
            Result=new Bitmap(300,300);
            using(var g=Graphics.FromImage(Result))
            {g.SmoothingMode=SmoothingMode.AntiAlias;g.InterpolationMode=InterpolationMode.HighQualityBicubic;using var path=new GraphicsPath();path.AddEllipse(0,0,300,300);g.SetClip(path);PaintPhoto(g,150,150);}
            DialogResult=DialogResult.OK;Close();
        };
    }
    void LoadPhoto()
    {
        using var file=new OpenFileDialog{Filter="Изображения|*.jpg;*.jpeg;*.png;*.bmp;*.webp|Все файлы|*.*"};
        if(file.ShowDialog()!=DialogResult.OK)return;
        try
        {
            using var image=Image.FromFile(file.FileName);
            if(image.PropertyIdList.Contains(0x112))
            {
                int o=image.GetPropertyItem(0x112)!.Value![0];
                image.RotateFlip(o switch{3=>RotateFlipType.Rotate180FlipNone,6=>RotateFlipType.Rotate90FlipNone,8=>RotateFlipType.Rotate270FlipNone,_=>RotateFlipType.RotateNoneFlipNone});
            }
            float factor=Math.Min(1,2048f/Math.Max(image.Width,image.Height));
            var next=new Bitmap(image,(int)(image.Width*factor),(int)(image.Height*factor));photo?.Dispose();photo=next;
            offset=PointF.Empty;zoom.Value=100;canvas.Invalidate();
        }
        catch(Exception ex){MessageBox.Show(this,"Не удалось открыть изображение. Попробуйте JPG или PNG.\n"+ex.Message,"Загрузка фото");}
    }
    void Clamp()
    {
        if(photo==null)return;
        float x=Math.Max(0,(photo.Width*Scale-300)/2),y=Math.Max(0,(photo.Height*Scale-300)/2);
        offset.X=Math.Clamp(offset.X,-x,x);offset.Y=Math.Clamp(offset.Y,-y,y);
    }
    void PaintPhoto(Graphics g,float x,float y)
    {
        if(photo==null)return;float w=photo.Width*Scale,h=photo.Height*Scale;
        g.DrawImage(photo,x-w/2+offset.X,y-h/2+offset.Y,w,h);
    }
    void Draw(object? sender,PaintEventArgs e)
    {
        var g=e.Graphics;g.Clear(Color.FromArgb(40,43,49));g.SmoothingMode=SmoothingMode.AntiAlias;g.InterpolationMode=InterpolationMode.HighQualityBicubic;
        float x=canvas.Width/2f,y=canvas.Height/2f;
        using var path=new GraphicsPath();path.AddEllipse(x-150,y-150,300,300);g.SetClip(path);g.Clear(Color.LightGray);PaintPhoto(g,x,y);g.ResetClip();
        using var pen=new Pen(Color.White,2);g.DrawEllipse(pen,x-150,y-150,300,300);
    }
    protected override void Dispose(bool disposing){if(disposing){photo?.Dispose();Result?.Dispose();}base.Dispose(disposing);}
    sealed class Preview:Panel{public Preview(){DoubleBuffered=true;}}
}
