using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
namespace Stickman;

internal readonly record struct Obstacle(IntPtr Id, Rectangle Rect);
internal static class ExplorerWindows
{
    delegate bool EnumProc(IntPtr hwnd, IntPtr data);
    [StructLayout(LayoutKind.Sequential)] struct Rect { public int Left,Top,Right,Bottom; }
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback,IntPtr data);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr h);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,StringBuilder text,int count);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h,out Rect r);
    [DllImport("dwmapi.dll",EntryPoint="DwmGetWindowAttribute")] static extern int Bounds(IntPtr h,int attr,out Rect r,int size);
    [DllImport("dwmapi.dll",EntryPoint="DwmGetWindowAttribute")] static extern int Attribute(IntPtr h,int attr,out int value,int size);
    public static List<Obstacle> Read(Rectangle area)
    {
        var result=new List<Obstacle>();
        EnumWindows((h,_)=>
        {
            if(!IsWindowVisible(h)||IsIconic(h)||IsZoomed(h)) return true;
            var name=new StringBuilder(128);GetClassName(h,name,128);
            if(name.ToString()!="CabinetWClass" && name.ToString()!="ExploreWClass") return true;
            if(Attribute(h,14,out int cloaked,4)==0 && cloaked!=0) return true;
            if(Bounds(h,9,out var r,16)!=0 && !GetWindowRect(h,out r)) return true;
            var rect=Rectangle.FromLTRB(r.Left,r.Top,r.Right,r.Bottom);
            if(rect.Width>40 && rect.Height>40 && rect.IntersectsWith(area)) result.Add(new(h,rect));
            return true;
        },IntPtr.Zero);
        return result;
    }
}

internal sealed partial class Body
{
    public List<Obstacle> Obstacles=new();
    readonly Vector2[] stepStart=new Vector2[14];
    int heldB; float heldT;
    IntPtr supportId;
    Rectangle supportRect;
    float SupportTop=>supportId==IntPtr.Zero?FloorAt(P[3].X):supportRect.Top;
    float InvMass(int i)=>i==Held && heldB==Held?0:1/mass[i];
    public void GrabSegment(int a,int b,float t,Vector2 target)
    { Grab(a,target);heldB=b;heldT=t; }
    void Pin(Vector2 target)
    {
        if(Held==heldB) {P[Held]=target;return;}
        float a=1-heldT,b=heldT;
        float wa=1/mass[Held],wb=1/mass[heldB];
        var delta=Limit(target-Vector2.Lerp(P[Held],P[heldB],heldT),28);
        float sum=wa*a*a+wb*b*b;
        P[Held]+=delta*(wa*a/sum);P[heldB]+=delta*(wb*b/sum);
    }
    void OrientShoulders()
    {
        var d=P[1]-P[3]; float len=d.Length(); if(len<1)return;
        var right=new Vector2(-d.Y,d.X)/len;
        for(int side=0;side<2;side++)
        {
            float sign=side==0?-1:1; int i=4+side;
            var goal=P[1]+right*(sign*8)-d/len*4;
            if(InvMass(i)>0) P[i]=Vector2.Lerp(P[i],goal,.45f);
            // Keep the left and right arms on their own side of the body.
            foreach(int j in new[]{6+side,8+side})
            {
                float lateral=Vector2.Dot(P[j]-P[1],right)*sign;
                float minimum=j<8?12:15;
                if(lateral<minimum && InvMass(j)>0) P[j]+=right*(sign*(minimum-lateral)*.6f);
            }
        }
    }
    public void SetObstacles(List<Obstacle> next)
    {
        if(supportId!=IntPtr.Zero)
        {
            var found=next.Find(o=>o.Id==supportId);
            if(found.Id!=IntPtr.Zero)
            {
                var delta=new Vector2(found.Rect.Left-supportRect.Left,found.Rect.Top-supportRect.Top);
                if(delta.Length()<300)
                {
                    for(int i=0;i<14;i++){P[i]+=delta;Old[i]+=delta;}
                    anchor+=delta.X;
                }
                supportRect=found.Rect;
            }
        }
        Obstacles=next;
    }
    void CheckSupport()
    {
        if(!Standing || supportId==IntPtr.Zero) return;
        bool valid=Obstacles.Any(o=>o.Id==supportId);
        bool beyond=anchor<supportRect.Left-5 || anchor>supportRect.Right+5;
        if(!valid||beyond)
        {
            Standing=false;Running=false;floorTime=0;releaseAge=0;recovery=0;supportId=IntPtr.Zero;
            for(int i=0;i<14;i++) Old[i]=P[i]-new Vector2(runSpeed,15)*Dt;
        }
    }
    bool FindLanding(out Obstacle support)
    {
        support=new Obstacle(IntPtr.Zero,new Rectangle(Area.Left,Area.Bottom,Area.Width,1));
        bool found=false;float top=Area.Bottom;
        for(int i=0;i<14;i++)
        {
            float foot=P[i].Y+Radius(i)+2;
            if(foot>FloorAt(P[i].X)-5)found=true;
            foreach(var o in Obstacles)
            {
                var r=o.Rect;
                if(P[i].X<r.Left||P[i].X>r.Right||MathF.Abs(foot-r.Top)>6)continue;
                if(P[3].X<r.Left-10||P[3].X>r.Right+10||P[3].Y>r.Top+8)continue;
                // Need space for the complete standing character, not a top at the screen ceiling.
                if(r.Top<Area.Top+140)continue;
                if(r.Top<=top){support=o;top=r.Top;found=true;}
            }
        }
        return found;
    }
    static bool Inside(Vector2 p,RectangleF r)=>p.X>r.Left&&p.X<r.Right&&p.Y>r.Top&&p.Y<r.Bottom;
    static Vector2 PushOut(Vector2 p,Vector2 previous,Rectangle box,float radius,out Vector2 normal)
    {
        var r=RectangleF.FromLTRB(box.Left-radius,box.Top-radius,box.Right+radius,box.Bottom+radius);
        normal=Vector2.Zero;
        if(!Inside(p,r))return p;
        // Prefer the side from which the point arrived; otherwise use shortest depenetration.
        if(previous.Y<=r.Top){normal=-Vector2.UnitY;p.Y=r.Top;}
        else if(previous.Y>=r.Bottom){normal=Vector2.UnitY;p.Y=r.Bottom;}
        else if(previous.X<=r.Left){normal=-Vector2.UnitX;p.X=r.Left;}
        else if(previous.X>=r.Right){normal=Vector2.UnitX;p.X=r.Right;}
        else
        {
            float left=p.X-r.Left,right=r.Right-p.X,up=p.Y-r.Top,down=r.Bottom-p.Y;
            float min=MathF.Min(MathF.Min(left,right),MathF.Min(up,down));
            if(min==up){normal=-Vector2.UnitY;p.Y=r.Top;}
            else if(min==down){normal=Vector2.UnitY;p.Y=r.Bottom;}
            else if(min==left){normal=-Vector2.UnitX;p.X=r.Left;}
            else{normal=Vector2.UnitX;p.X=r.Right;}
        }
        return p;
    }
    void CollideWindows(int i)
    {
        foreach(var o in Obstacles)
        {
            var p=P[i]; var corrected=PushOut(p,stepStart[i],o.Rect,Radius(i)+2,out var n);
            if(n==Vector2.Zero)continue;
            var velocity=P[i]-Old[i];float vn=Vector2.Dot(velocity,n);
            if(vn<0)velocity-=n*vn*1.28f;
            if(n.Y<0)velocity.X*=Standing?.94f:.87f;
            P[i]=corrected;Old[i]=corrected-Limit(velocity,2200*Dt);
            if(Standing && MathF.Abs(n.X)>.5f && runSpeed*n.X<0)
            {anchor=P[3].X;runSpeed*=.6f;}
        }
    }
    void CollideBones()
    {
        foreach(var link in Lines)
        {
            foreach(var o in Obstacles)
            {
                // Capsule samples keep mid-limb sections from clipping window edges.
                for(int sample=1;sample<=3;sample++)
                {
                    float t=sample*.25f,a=1-t;
                    var p=Vector2.Lerp(P[link.A],P[link.B],t);
                    var prev=Vector2.Lerp(stepStart[link.A],stepStart[link.B],t);
                    var q=PushOut(p,prev,o.Rect,6.5f,out var n);
                    if(n==Vector2.Zero)continue;
                    float wa=InvMass(link.A),wb=InvMass(link.B),sum=wa*a*a+wb*t*t;
                    if(sum<.001f)continue;
                    var c=Limit(q-p,20);
                    var ca=c*(wa*a/sum);var cb=c*(wb*t/sum);
                    P[link.A]+=ca;P[link.B]+=cb;Old[link.A]+=ca;Old[link.B]+=cb;
                }
            }
        }
        for(int i=0;i<14;i++){CollideWindows(i);Collide(i,true);}
    }
}
