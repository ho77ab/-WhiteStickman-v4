using System.Numerics;
namespace Stickman;
internal sealed partial class Body
{
    public bool Hunter,Attached;
    public Rectangle[] Screens=Array.Empty<Rectangle>();
    float calm,landingCrouch,jumpCooldown,attachAge;
    bool jumping;
    Vector2 previousMouse; bool mouseReady;
    public float FloorAt(float x)
    {
        var candidates=Screens.Where(r=>x>=r.Left && x<=r.Right).ToArray();
        return candidates.Length==0?Area.Bottom:candidates.OrderBy(r=>MathF.Abs(r.Bottom-P[3].Y)).First().Bottom;
    }
    public void Detach(Vector2 v)
    {if(!Attached)return;Attached=false;Release(Limit(v,850));jumpCooldown=1.5f;calm=1;}
    void Launch(Vector2 v)
    {
        Standing=false;Running=false;supportId=IntPtr.Zero;releaseAge=0;floorTime=0;
        jumping=true;jumpCooldown=1.1f;
        for(int i=0;i<14;i++)Old[i]=P[i]-v*Dt;
    }
    public void Control(Vector2 mouse)
    {
        calm=MathF.Max(0,calm-Dt);landingCrouch=MathF.Max(0,landingCrouch-Dt*2.5f);jumpCooldown=MathF.Max(0,jumpCooldown-Dt);
        var mv=mouseReady?(mouse-previousMouse)/Dt:Vector2.Zero;previousMouse=mouse;mouseReady=true;
        if(Attached)
        {
            attachAge+=Dt;
            if(!Hunter || (attachAge>.25f && mv.Length()>2100)){Detach(mv);return;}
            Target=mouse;return;
        }
        if(Hunter && Held<0 && calm<=0 && jumpCooldown<.8f)
        {
            for(int i=8;i<=9;i++)if(Vector2.Distance(P[i],mouse)<21)
            {Grab(i,mouse);Attached=true;attachAge=0;return;}
        }
        if(!Standing||Held>=0||calm>0||recovery<.9f||jumpCooldown>0)return;
        if(supportId!=IntPtr.Zero && MathF.Abs(runSpeed)>50)
        {
            float dir=MathF.Sign(runSpeed);
            float edge=dir>0?supportRect.Right:supportRect.Left;
            if((edge-anchor)*dir<42)
            {
                foreach(var o in Obstacles.OrderBy(o=>MathF.Abs(o.Rect.Left-anchor)))
                {
                    if(o.Id==supportId||o.Rect.Top<Area.Top+150)continue;
                    float target=dir>0?o.Rect.Left+50:o.Rect.Right-50;
                    float dx=target-anchor,dy=o.Rect.Top-supportRect.Top;
                    if(dx*dir<45||dx*dir>470||dy< -150||dy>260)continue;
                    float vy=-610,disc=vy*vy+2400*dy;
                    if(disc<=0)continue;
                    float t=(-vy+MathF.Sqrt(disc))/1200;
                    float vx=dx/t*1.12f;
                    if(MathF.Abs(vx)>520)continue;
                    Launch(new Vector2(vx,vy));return;
                }
            }
        }
        if(Hunter)
        {
            var delta=mouse-P[0];
            if(MathF.Abs(delta.X)<250 && delta.Y<40 && delta.Y> -320)
                Launch(new Vector2(Math.Clamp(delta.X*2.4f,-430,430),-Math.Clamp(470-delta.Y,470,780)));
        }
    }
    public void AfterStep()
    {
        // Damp contact energy before the cursor can trigger any locomotion.
        if(!Standing && Held<0 && FindLanding(out _))
        {
            for(int i=0;i<14;i++)Old[i]=P[i]-(P[i]-Old[i])*.80f;
        }
        if(jumping && !Standing && Held<0)
        {
            // Preserve an upright silhouette during an intentional jump.
            var up=P[1]-P[3];float error=MathF.Atan2(up.X,-up.Y);
            var center=Center;float turn=-error*.035f;
            float c=MathF.Cos(turn),s=MathF.Sin(turn);
            for(int i=0;i<14;i++)
            {
                var d=P[i]-center;var change=new Vector2(d.X*c-d.Y*s,d.X*s+d.Y*c)-d;
                P[i]+=change;Old[i]+=change;
            }
            if(releaseAge>1.7f)jumping=false;
        }
        if(Screens.Length==0)return;
        // Project points out of gaps between monitors; adjacent screens share an open boundary.
        for(int i=0;i<14;i++)
        {
            var p=P[i];if(Screens.Any(r=>r.Contains((int)p.X,(int)p.Y)))continue;
            Vector2 best=p;float distance=float.MaxValue;
            foreach(var r in Screens)
            {
                var q=Vector2.Clamp(p,new Vector2(r.Left+Radius(i),r.Top+Radius(i)),new Vector2(r.Right-Radius(i),r.Bottom-Radius(i)));
                float d=Vector2.DistanceSquared(p,q);if(d<distance){distance=d;best=q;}
            }
            P[i]=best;Old[i]=best;
        }
    }
}
